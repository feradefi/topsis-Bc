
<h1 class="text-center" style="font-weight: 700;">Alternatif</h1>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <ul class="nav nav-pills">
                <?php
                $act1 = ($_GET['k'] == 'alternatif') ? 'active' : '';
                $act2 = ($_GET['k'] == 'tambah') ? 'active' : '';
                ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo $act1; ?>" href="index.php?a=alternatif&k=alternatif">Data Alternatif</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $act2; ?>" href="index.php?a=alternatif&k=tambah">Tambah Alternatif</a>
					<br>
                </li>
            </ul>
        </div>
    </div>
</div>


<?php

if(@$_GET['a']=='alternatif' and @$_GET['k']=='alternatif'){
	include ("dataalternatif.php");
 }else if(@$_GET['k']=='tambah'){
	include ("tambahalternatif.php");
 }else if(@$_GET['k']=='ubaha'){
	include ("ubahalternatif.php");
 }
 ?>
