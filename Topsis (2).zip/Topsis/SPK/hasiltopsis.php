
<h1 class="text-center" style="font-weight: 700;">Hasil Topsis</h1>
<ul class="nav nav-tabs">
    <?php
    $act1 = ($_GET['k'] == 'nilai_matriks') ? 'active' : '';
    $act2 = ($_GET['k'] == 'nilai_matriks_normalisasi') ? 'active' : '';
    $act3 = ($_GET['k'] == 'nilai_bobot_normalisasi') ? 'active' : '';
    $act4 = ($_GET['k'] == 'matriks_ideal') ? 'active' : '';
    $act5 = ($_GET['k'] == 'jarak_solusi') ? 'active' : '';
    $act6 = ($_GET['k'] == 'nilai_preferensi') ? 'active' : '';
    ?>
    <li class="nav-item">
        <a class="nav-link <?php echo $act1; ?>" href="index.php?a=hasiltopsis&k=nilai_matriks">Nilai Matriks</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo $act2; ?>" href="index.php?a=hasiltopsis&k=nilai_matriks_normalisasi">Nilai Matriks Ternormalisasi</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo $act3; ?>" href="index.php?a=hasiltopsis&k=nilai_bobot_normalisasi">Nilai Bobot Ternormalisasi</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo $act4; ?>" href="index.php?a=hasiltopsis&k=matriks_ideal">Matriks Ideal Posistif/Negatif</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo $act5; ?>" href="index.php?a=hasiltopsis&k=jarak_solusi">Jarak Solusi Ideal Posistif/Negatif</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo $act6; ?>" href="index.php?a=hasiltopsis&k=nilai_preferensi">Nilai Preferensi</a>
    </li>
</ul>


<?php

if(@$_GET['a']=='hasiltopsis' and @$_GET['k']=='nilai_matriks'){
	include ("nilai_matriks.php");
 }else if(@$_GET['k']=='nilai_matriks_normalisasi'){
	include ("nilai_matriks_normalisasi.php");
 }else if(@$_GET['k']=='nilai_bobot_normalisasi'){
	include ("nilai_bobot_normalisasi.php");
 }else if(@$_GET['k']=='matriks_ideal'){
	include ("matriks_ideal.php");
 }else if(@$_GET['k']=='jarak_solusi'){
	include ("jarak_solusi.php");
 }else if(@$_GET['k']=='nilai_preferensi'){
	include ("nilai_preferensi.php");
 }
 ?>
