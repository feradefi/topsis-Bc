<?php
include("konfig/koneksi.php");
$kriteria_sifat = array();
$s = mysqli_query($conn, "SELECT * FROM kriteria");
$h = mysqli_num_rows($s);
while ($row = mysqli_fetch_assoc($s)) {
    $kriteria_sifat[$row['id_kriteria']] = $row['sifat'];
}
?>
<h1 class="text-center" style="font-weight: 700;">Kriteria</h1>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <ul class="nav nav-pills">
                <?php
                $act1 = ($_GET['k'] == 'kriteria') ? 'active' : '';
                $act2 = ($_GET['k'] == 'tambah') ? 'active' : '';
                ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo $act1; ?>" href="index.php?a=kriteria&k=kriteria">Data Kriteria</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $act2; ?>" href="index.php?a=kriteria&k=tambah">Tambah Kriteria</a>
					<br>
                </li>
            </ul>
        </div>
    </div>
</div>

<?php

if (@$_GET['a'] == 'kriteria' and @$_GET['k'] == 'kriteria') {
	include("datakriteria.php");
} else if (@$_GET['k'] == 'tambah') {
	include("tambahkriteria.php");
} else if (@$_GET['k'] == 'ubahk') {
	include("ubahkriteria.php");
}
?>