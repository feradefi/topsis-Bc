<!DOCTYPE html>
<html lang="en">

<head>
    <title>TOPSIS</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <style>
        body {
            background-color: #F0FFF0;
            font-family: 'Arial', sans-serif;
        }

        .navbar {
            height: 100px;
            background-color: #333;
        }

        .navbar-brand {
            margin: auto;
            font-size: 30px;
            color: white !important;
        }

        .welcome-message {
            text-align: center;
            font-size: 20px;
            margin: 20px 0;
            color: #333;
        }

        .nav-pills .nav-link {
            color: #333;
        }

        .nav-pills .nav-link.active {
            background-color: #007BFF;
            color: white;
        }

        .nav-pills .nav-link:hover {
            background-color: #007BFF;
            color: white;
        }

        .content {
            padding: 20px;
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand">SPK PEMILIHAN KARYAWAN TETAP</a>
    </nav>

    <div class="welcome-message">
        SELAMAT DATANG DI WEB TOPSIS SPK PEMILIHAN KARYAWAN TETAP<br>SILAHKAN KLIK MENU YANG TERSEDIA
    </div>


    <?php
    if (@$_GET['a'] == 'kriteria') {
        $active1 = 'active';
        $active2 = '';
        $active3 = '';
        $active4 = '';
    } else if (@$_GET['a'] == 'alternatif') {
        $active1 = '';
        $active2 = 'active';
        $active3 = '';
        $active4 = '';
    } else if (@$_GET['a'] == 'nilaimatrik') {
        $active1 = '';
        $active2 = '';
        $active3 = 'active';
        $active4 = '';
    } else if (@$_GET['a'] == 'hasiltopsis') {
        $active1 = '';
        $active2 = '';
        $active3 = '';
        $active4 = 'active';
    } else {
        $active1 = '';
        $active2 = '';
        $active3 = '';
        $active4 = '';
    }
    ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-2">
                <ul class="nav nav-pills flex-column">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $active1 ?>" href="?a=kriteria&k=kriteria">Kriteria</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $active2 ?>" href="?a=alternatif&k=alternatif">Alternatif</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $active3 ?>" href="?a=nilaimatrik">Nilai Matriks</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $active4 ?>" href="?a=hasiltopsis&k=nilai_matriks">Hasil Topsis</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>

            <div class="col-sm-10 content">
                <?php
                if (@$_GET['a'] == 'kriteria') {
                    include("kriteria.php");
                } else if (@$_GET['a'] == 'alternatif') {
                    include("alternatif.php");
                } else if (@$_GET['a'] == 'nilaimatrik') {
                    include("nilaimatrik.php");
                } else if (@$_GET['a'] == 'hasiltopsis') {
                    include("hasiltopsis.php");
                }
                ?>
            </div>
        </div>
    </div>

</body>

</html>
